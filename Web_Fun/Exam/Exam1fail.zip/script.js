function addToCart(num) {
    var cart = document.querySelector('#cart');
    var cart_num = parseInt(cart.textContent);
    cart.textContent = cart_num + 1;
}

